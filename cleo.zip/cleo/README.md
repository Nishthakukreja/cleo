# ✦ Cleo — AI, made human.

> An AI that teaches people how to use AI. Built for non-tech people.

---

## What Cleo does

1. **Onboards you personally** — asks your job and goals, gives you tailored prompts
2. **Chats in plain English** — no jargon, patient, encouraging
3. **Improves your prompts** — scores your prompt and gives you a better version

---

## Setup (do this at home tonight)

### 1. Get your Gemini API key
- Go to [aistudio.google.com](https://aistudio.google.com)
- Click "Get API Key" → "Create API Key"
- Copy it

### 2. Backend setup
```bash
cd backend
cp .env.example .env
# Open .env and paste your Gemini API key

pip install -r requirements.txt
uvicorn main:app --reload
```
Backend runs at http://localhost:8000

### 3. Frontend setup
```bash
cd frontend
npm install
npm run dev
```
Frontend runs at http://localhost:5173

### 4. Open it
Go to http://localhost:5173 — Cleo is live!

---

## Project structure

```
cleo/
├── backend/
│   ├── main.py          # FastAPI server + Gemini integration
│   ├── requirements.txt
│   └── .env.example     # Copy to .env and add your key
└── frontend/
    ├── src/
    │   ├── pages/
    │   │   ├── Landing.jsx   # Homepage
    │   │   ├── Onboarding.jsx # Personalization flow
    │   │   └── Chat.jsx      # Main chat interface
    │   ├── App.jsx
    │   └── index.css
    └── package.json
```

---

## Tech stack

- **Frontend:** React + Vite
- **Backend:** Python + FastAPI
- **AI:** Google Gemini 1.5 Flash (free tier)
- **Streaming:** Server-Sent Events

---

Built with 🤍
