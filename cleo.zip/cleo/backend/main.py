from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Optional
import google.generativeai as genai
import os
import json
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# --- Prompts ---

ONBOARDING_SYSTEM_PROMPT = """
You are Cleo, a warm and friendly AI guide whose only job is helping people understand and use AI effectively.
You are NOT a general assistant. You help people learn AI.

When a user tells you their job/background, you must:
1. Warmly acknowledge their background
2. Explain AI in terms that relate directly to their work
3. Give them 3 specific, ready-to-use prompts tailored to their job
4. Keep your tone conversational, encouraging, and jargon-free
5. Never use technical terms like "LLM", "tokens", "parameters"

Format your response as JSON with this exact structure:
{
  "greeting": "A warm 1-2 sentence welcome personalized to their job",
  "explanation": "A 2-3 sentence explanation of what AI can do for someone in their role, using their own language",
  "prompts": [
    {"title": "Short title", "prompt": "The actual ready-to-use prompt they can copy", "why": "One sentence on why this helps them"},
    {"title": "Short title", "prompt": "The actual ready-to-use prompt they can copy", "why": "One sentence on why this helps them"},
    {"title": "Short title", "prompt": "The actual ready-to-use prompt they can copy", "why": "One sentence on why this helps them"}
  ],
  "encouragement": "A single short sentence to motivate them to try"
}
"""

CHAT_SYSTEM_PROMPT = """
You are Cleo, a warm, patient, and encouraging AI guide. Your purpose is to help people who are new to AI understand how to use it effectively.

Your personality:
- Warm, friendly, never condescending
- You explain things like a knowledgeable friend, not a textbook
- You celebrate when users try things
- You never use jargon without immediately explaining it
- When someone struggles, you offer simpler alternatives

Your job in every response:
1. Answer their question clearly
2. If they wrote a prompt, tell them what worked and what could be better
3. If they're confused, give them an exact example they can copy
4. Always end with one encouraging nudge to try something

Remember: your users are NOT tech people. They are marketers, teachers, nurses, business owners, students. Speak their language.
"""

# --- Models ---

class OnboardingRequest(BaseModel):
    job: str
    goal: str

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[Message]
    user_context: Optional[str] = None

# --- Routes ---

@app.get("/")
def root():
    return {"status": "Cleo is running"}

@app.post("/onboard")
async def onboard(req: OnboardingRequest):
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY not set")
    
    try:
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            system_instruction=ONBOARDING_SYSTEM_PROMPT
        )
        
        user_message = f"My job is: {req.job}\nWhat I want to use AI for: {req.goal}"
        response = model.generate_content(user_message)
        
        raw = response.text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip()
        
        data = json.loads(raw)
        return data
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Failed to parse AI response")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/chat")
async def chat(req: ChatRequest):
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY not set")
    
    try:
        system = CHAT_SYSTEM_PROMPT
        if req.user_context:
            system += f"\n\nUser context: {req.user_context}"
        
        model = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            system_instruction=system
        )
        
        history = []
        messages = req.messages
        
        for msg in messages[:-1]:
            history.append({
                "role": "user" if msg.role == "user" else "model",
                "parts": [msg.content]
            })
        
        chat_session = model.start_chat(history=history)
        last_message = messages[-1].content
        
        def generate():
            response = chat_session.send_message(last_message, stream=True)
            for chunk in response:
                if chunk.text:
                    yield f"data: {json.dumps({'text': chunk.text})}\n\n"
            yield "data: [DONE]\n\n"
        
        return StreamingResponse(generate(), media_type="text/event-stream")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/improve-prompt")
async def improve_prompt(req: dict):
    if not GEMINI_API_KEY:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY not set")
    
    try:
        model = genai.GenerativeModel(model_name="gemini-1.5-flash")
        
        prompt_text = req.get("prompt", "")
        context = req.get("context", "")
        
        instruction = f"""
        A user wrote this AI prompt: "{prompt_text}"
        Their job/context: {context}
        
        Respond in JSON:
        {{
          "score": <1-10 rating>,
          "what_works": "what's good about this prompt in one sentence",
          "improvement": "one specific thing to make it better",
          "improved_version": "the rewritten, better prompt",
          "tip": "one general prompting tip for next time"
        }}
        """
        
        response = model.generate_content(instruction)
        raw = response.text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip()
        
        return json.loads(raw)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
