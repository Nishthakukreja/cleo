import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import './Onboarding.css'

const STEPS = [
  {
    id: 'job',
    question: "What do you do for work?",
    hint: "Be as specific as you like — the more detail, the better Cleo can help you.",
    placeholder: "e.g. I'm a marketing manager at a retail company...",
    type: 'textarea',
  },
  {
    id: 'goal',
    question: "What do you hope AI can help you with?",
    hint: "There's no wrong answer. Even 'I have no idea' is a great start.",
    placeholder: "e.g. Save time on emails, understand what the hype is about, help me think...",
    type: 'textarea',
  }
]

export default function Onboarding({ onComplete }) {
  const navigate = useNavigate()
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState({ job: '', goal: '' })
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  const current = STEPS[step]
  const value = answers[current.id]

  const handleNext = async () => {
    if (!value.trim()) return

    if (step < STEPS.length - 1) {
      setStep(s => s + 1)
      return
    }

    // Last step — call API
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ job: answers.job, goal: answers.goal }),
      })
      if (!res.ok) throw new Error('Something went wrong')
      const data = await res.json()
      setResult(data)
    } catch (e) {
      setError("Cleo couldn't connect right now. Make sure the API key is set up!")
    } finally {
      setLoading(false)
    }
  }

  const handleStartChat = () => {
    onComplete({ job: answers.job, goal: answers.goal, result })
    navigate('/chat')
  }

  if (loading) {
    return (
      <div className="onboarding onboarding--loading">
        <div className="loading-orb" />
        <p className="loading-text">Cleo is getting to know you...</p>
      </div>
    )
  }

  if (result) {
    return (
      <div className="onboarding">
        <div className="onboard-result">
          <div className="result-logo">
            <span className="logo-mark">✦</span>
            <span className="logo-name">Cleo</span>
          </div>

          <p className="result-greeting">{result.greeting}</p>
          <p className="result-explanation">{result.explanation}</p>

          <div className="prompts-section">
            <p className="prompts-label">Try these — they're made just for you:</p>
            <div className="prompts-list">
              {result.prompts?.map((p, i) => (
                <div key={i} className="prompt-card">
                  <div className="prompt-header">
                    <span className="prompt-num">0{i + 1}</span>
                    <span className="prompt-title">{p.title}</span>
                  </div>
                  <p className="prompt-text">"{p.prompt}"</p>
                  <p className="prompt-why">{p.why}</p>
                </div>
              ))}
            </div>
          </div>

          <p className="result-encouragement">{result.encouragement}</p>

          <button className="start-btn" onClick={handleStartChat}>
            Start chatting with Cleo
            <span>→</span>
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="onboarding">
      <div className="onboard-card">
        <div className="onboard-logo">
          <span className="logo-mark">✦</span>
          <span className="logo-name">Cleo</span>
        </div>

        <div className="step-indicator">
          {STEPS.map((_, i) => (
            <div key={i} className={`step-dot ${i === step ? 'active' : i < step ? 'done' : ''}`} />
          ))}
        </div>

        <h2 className="onboard-question">{current.question}</h2>
        <p className="onboard-hint">{current.hint}</p>

        <textarea
          className="onboard-input"
          placeholder={current.placeholder}
          value={value}
          onChange={e => setAnswers(a => ({ ...a, [current.id]: e.target.value }))}
          rows={4}
          autoFocus
          onKeyDown={e => {
            if (e.key === 'Enter' && e.metaKey) handleNext()
          }}
        />

        {error && <p className="onboard-error">{error}</p>}

        <div className="onboard-actions">
          {step > 0 && (
            <button className="back-btn" onClick={() => setStep(s => s - 1)}>
              ← Back
            </button>
          )}
          <button
            className="next-btn"
            onClick={handleNext}
            disabled={!value.trim()}
          >
            {step === STEPS.length - 1 ? 'Meet Cleo →' : 'Continue →'}
          </button>
        </div>

        <p className="onboard-meta">⌘ + Enter to continue</p>
      </div>
    </div>
  )
}
