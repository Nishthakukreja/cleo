import React, { useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import './Landing.css'

const FLOATING_WORDS = [
  "Write an email for me",
  "Explain this to me simply",
  "Help me prepare for my meeting",
  "What should I say here?",
  "Make this sound better",
  "Summarize this document",
  "Give me ideas for...",
  "How do I ask AI to...",
]

export default function Landing() {
  const navigate = useNavigate()
  const orbRef = useRef(null)

  useEffect(() => {
    const handleMouse = (e) => {
      if (!orbRef.current) return
      const x = (e.clientX / window.innerWidth - 0.5) * 30
      const y = (e.clientY / window.innerHeight - 0.5) * 30
      orbRef.current.style.transform = `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`
    }
    window.addEventListener('mousemove', handleMouse)
    return () => window.removeEventListener('mousemove', handleMouse)
  }, [])

  return (
    <div className="landing">
      {/* Background orb */}
      <div className="orb" ref={orbRef} />

      {/* Floating words */}
      <div className="floating-words" aria-hidden="true">
        {FLOATING_WORDS.map((word, i) => (
          <span
            key={i}
            className="floating-word"
            style={{
              '--delay': `${i * 0.4}s`,
              '--x': `${10 + (i * 11.5) % 80}%`,
              '--y': `${8 + (i * 13) % 75}%`,
            }}
          >
            {word}
          </span>
        ))}
      </div>

      {/* Nav */}
      <nav className="landing-nav">
        <div className="logo">
          <span className="logo-mark">✦</span>
          <span className="logo-name">Cleo</span>
        </div>
      </nav>

      {/* Hero */}
      <main className="hero">
        <div className="hero-eyebrow">AI, made human.</div>

        <h1 className="hero-headline">
          You don't need to be
          <br />
          <em>a tech person</em> to use AI.
        </h1>

        <p className="hero-sub">
          Cleo meets you where you are — your job, your words, your pace.
          <br />
          No jargon. No confusion. Just AI that actually works for you.
        </p>

        <button
          className="hero-cta"
          onClick={() => navigate('/start')}
        >
          Meet Cleo
          <span className="cta-arrow">→</span>
        </button>

        <p className="hero-hint">Takes 30 seconds. No signup needed.</p>
      </main>

      {/* Bottom strip */}
      <div className="bottom-strip">
        <span>Built for marketers</span>
        <span className="dot">·</span>
        <span>teachers</span>
        <span className="dot">·</span>
        <span>business owners</span>
        <span className="dot">·</span>
        <span>nurses</span>
        <span className="dot">·</span>
        <span>anyone curious</span>
      </div>
    </div>
  )
}
