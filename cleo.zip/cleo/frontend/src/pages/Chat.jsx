import React, { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import './Chat.css'

function Message({ msg }) {
  const isUser = msg.role === 'user'
  return (
    <div className={`message ${isUser ? 'message--user' : 'message--cleo'}`}>
      {!isUser && (
        <div className="cleo-avatar">✦</div>
      )}
      <div className="message-bubble">
        {msg.content.split('\n').map((line, i) => (
          <React.Fragment key={i}>
            {line}
            {i < msg.content.split('\n').length - 1 && <br />}
          </React.Fragment>
        ))}
      </div>
    </div>
  )
}

function TypingIndicator() {
  return (
    <div className="message message--cleo">
      <div className="cleo-avatar">✦</div>
      <div className="message-bubble typing-bubble">
        <span /><span /><span />
      </div>
    </div>
  )
}

const SUGGESTIONS = [
  "What can I actually use AI for in my job?",
  "How do I write a good prompt?",
  "Can you show me an example?",
  "What's the difference between AI tools?",
]

export default function Chat({ userContext }) {
  const navigate = useNavigate()
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: userContext?.result?.greeting
        ? `${userContext.result.greeting}\n\nI've set up your personalized experience. Feel free to ask me anything — or try one of the suggestions below to get started!`
        : "Hi! I'm Cleo. I'm here to help you get comfortable with AI — no jargon, no judgment. What would you like to know?",
    }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [showImprove, setShowImprove] = useState(false)
  const [improveResult, setImproveResult] = useState(null)
  const [improveLoading, setImproveLoading] = useState(false)
  const bottomRef = useRef(null)
  const inputRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  const sendMessage = async (text) => {
    const userMsg = text || input.trim()
    if (!userMsg || loading) return
    setInput('')

    const newMessages = [...messages, { role: 'user', content: userMsg }]
    setMessages(newMessages)
    setLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages,
          user_context: userContext ? `Job: ${userContext.job}. Goal: ${userContext.goal}` : null,
        }),
      })

      if (!res.ok) throw new Error('Failed')

      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let assistantText = ''

      setMessages(m => [...m, { role: 'assistant', content: '' }])
      setLoading(false)

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value)
        const lines = chunk.split('\n')
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6)
            if (data === '[DONE]') break
            try {
              const parsed = JSON.parse(data)
              if (parsed.text) {
                assistantText += parsed.text
                setMessages(m => {
                  const updated = [...m]
                  updated[updated.length - 1] = { role: 'assistant', content: assistantText }
                  return updated
                })
              }
            } catch {}
          }
        }
      }
    } catch {
      setLoading(false)
      setMessages(m => [...m, {
        role: 'assistant',
        content: "I had trouble connecting. Make sure the backend is running and your API key is set!"
      }])
    }
  }

  const handleImprove = async () => {
    if (!input.trim()) return
    setImproveLoading(true)
    setShowImprove(true)
    try {
      const res = await fetch('/api/improve-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: input,
          context: userContext ? `${userContext.job} - ${userContext.goal}` : '',
        }),
      })
      const data = await res.json()
      setImproveResult(data)
    } catch {
      setImproveResult({ error: true })
    } finally {
      setImproveLoading(false)
    }
  }

  return (
    <div className="chat-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-logo" onClick={() => navigate('/')}>
          <span className="logo-mark">✦</span>
          <span className="logo-name">Cleo</span>
        </div>

        {userContext?.result?.prompts && (
          <div className="sidebar-section">
            <p className="sidebar-label">Your prompts</p>
            {userContext.result.prompts.map((p, i) => (
              <button
                key={i}
                className="sidebar-prompt"
                onClick={() => sendMessage(p.prompt)}
              >
                <span className="sidebar-prompt-title">{p.title}</span>
              </button>
            ))}
          </div>
        )}

        <div className="sidebar-section">
          <p className="sidebar-label">Quick actions</p>
          {SUGGESTIONS.map((s, i) => (
            <button key={i} className="sidebar-prompt" onClick={() => sendMessage(s)}>
              <span className="sidebar-prompt-title">{s}</span>
            </button>
          ))}
        </div>

        <div className="sidebar-bottom">
          <button className="new-chat-btn" onClick={() => navigate('/start')}>
            + New profile
          </button>
        </div>
      </aside>

      {/* Main chat */}
      <main className="chat-main">
        <div className="messages-area">
          {messages.map((msg, i) => (
            <Message key={i} msg={msg} />
          ))}
          {loading && <TypingIndicator />}
          <div ref={bottomRef} />
        </div>

        {/* Improve prompt panel */}
        {showImprove && (
          <div className="improve-panel">
            <div className="improve-header">
              <span>Prompt feedback</span>
              <button onClick={() => { setShowImprove(false); setImproveResult(null) }}>✕</button>
            </div>
            {improveLoading ? (
              <p className="improve-loading">Analyzing your prompt...</p>
            ) : improveResult && !improveResult.error ? (
              <div className="improve-content">
                <div className="improve-score">
                  <span className="score-label">Score</span>
                  <span className="score-value">{improveResult.score}/10</span>
                </div>
                <p className="improve-field"><strong>What works:</strong> {improveResult.what_works}</p>
                <p className="improve-field"><strong>To improve:</strong> {improveResult.improvement}</p>
                <div className="improve-version">
                  <p className="improve-version-label">Better version:</p>
                  <p className="improve-version-text">"{improveResult.improved_version}"</p>
                  <button className="use-improved-btn" onClick={() => {
                    setInput(improveResult.improved_version)
                    setShowImprove(false)
                    setImproveResult(null)
                    inputRef.current?.focus()
                  }}>
                    Use this →
                  </button>
                </div>
                <p className="improve-tip">💡 {improveResult.tip}</p>
              </div>
            ) : (
              <p className="improve-loading">Couldn't analyze — try again!</p>
            )}
          </div>
        )}

        {/* Input area */}
        <div className="input-area">
          <div className="input-wrapper">
            <textarea
              ref={inputRef}
              className="chat-input"
              placeholder="Ask Cleo anything about AI..."
              value={input}
              onChange={e => setInput(e.target.value)}
              rows={1}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  sendMessage()
                }
              }}
              onInput={e => {
                e.target.style.height = 'auto'
                e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px'
              }}
            />
            <div className="input-actions">
              <button
                className="improve-btn"
                onClick={handleImprove}
                disabled={!input.trim()}
                title="Check your prompt"
              >
                ✦ Check prompt
              </button>
              <button
                className="send-btn"
                onClick={() => sendMessage()}
                disabled={!input.trim() || loading}
              >
                →
              </button>
            </div>
          </div>
          <p className="input-hint">Enter to send · Shift+Enter for new line · ✦ to improve your prompt</p>
        </div>
      </main>
    </div>
  )
}
