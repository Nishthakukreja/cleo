import React, { useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Landing from './pages/Landing.jsx'
import Onboarding from './pages/Onboarding.jsx'
import Chat from './pages/Chat.jsx'

export default function App() {
  const [userContext, setUserContext] = useState(null)

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route
          path="/start"
          element={<Onboarding onComplete={(ctx) => setUserContext(ctx)} />}
        />
        <Route
          path="/chat"
          element={
            userContext
              ? <Chat userContext={userContext} />
              : <Navigate to="/start" replace />
          }
        />
      </Routes>
    </BrowserRouter>
  )
}
